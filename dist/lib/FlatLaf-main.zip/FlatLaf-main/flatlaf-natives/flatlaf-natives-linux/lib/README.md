Contains libraries used to compile FlatLaf native libraries.

- `aarch64/libjawt.so` is `<jdk>/lib/libjawt.so` from Eclipse Temurin 11.0.25+9 aarch64,
  which is required to cross build aarch64/arm64 .so on x86_64
